﻿namespace FootballLife_WF
{
    partial class VerJogo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VerJogo));
            this.lbl_Titulo = new System.Windows.Forms.Label();
            this.btn_Fechar = new System.Windows.Forms.Button();
            this.lbl_Data = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_Escalao = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_EquipaCasa = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbl_GolosCasa = new System.Windows.Forms.Label();
            this.img_LogoCasa = new System.Windows.Forms.PictureBox();
            this.img_LogoFora = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_GolosFora = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_EquipaFora = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lbl_Divisao = new System.Windows.Forms.Label();
            this.flowpanel_Golos = new System.Windows.Forms.FlowLayoutPanel();
            this.label10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.img_LogoCasa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_LogoFora)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_Titulo
            // 
            this.lbl_Titulo.AutoSize = true;
            this.lbl_Titulo.Font = new System.Drawing.Font("Bauhaus 93", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Titulo.Location = new System.Drawing.Point(179, 27);
            this.lbl_Titulo.Name = "lbl_Titulo";
            this.lbl_Titulo.Size = new System.Drawing.Size(56, 24);
            this.lbl_Titulo.TabIndex = 4;
            this.lbl_Titulo.Text = "Jogo";
            // 
            // btn_Fechar
            // 
            this.btn_Fechar.BackColor = System.Drawing.Color.White;
            this.btn_Fechar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Fechar.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn_Fechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Fechar.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Fechar.ForeColor = System.Drawing.Color.Black;
            this.btn_Fechar.Location = new System.Drawing.Point(440, 565);
            this.btn_Fechar.Name = "btn_Fechar";
            this.btn_Fechar.Size = new System.Drawing.Size(92, 34);
            this.btn_Fechar.TabIndex = 30;
            this.btn_Fechar.Text = "Fechar";
            this.btn_Fechar.UseVisualStyleBackColor = false;
            this.btn_Fechar.Click += new System.EventHandler(this.Btn_Fechar_Click);
            // 
            // lbl_Data
            // 
            this.lbl_Data.AutoSize = true;
            this.lbl_Data.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Data.Location = new System.Drawing.Point(77, 98);
            this.lbl_Data.Name = "lbl_Data";
            this.lbl_Data.Size = new System.Drawing.Size(34, 15);
            this.lbl_Data.TabIndex = 31;
            this.lbl_Data.Text = "teste";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Berlin Sans FB Demi", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 18);
            this.label1.TabIndex = 32;
            this.label1.Text = "Data:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Berlin Sans FB Demi", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(215, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 18);
            this.label2.TabIndex = 34;
            this.label2.Text = "Escalão:";
            // 
            // lbl_Escalao
            // 
            this.lbl_Escalao.AutoSize = true;
            this.lbl_Escalao.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Escalao.Location = new System.Drawing.Point(284, 98);
            this.lbl_Escalao.Name = "lbl_Escalao";
            this.lbl_Escalao.Size = new System.Drawing.Size(34, 15);
            this.lbl_Escalao.TabIndex = 33;
            this.lbl_Escalao.Text = "teste";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Berlin Sans FB Demi", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(41, 286);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 18);
            this.label3.TabIndex = 36;
            this.label3.Text = "Equipa Casa:";
            // 
            // lbl_EquipaCasa
            // 
            this.lbl_EquipaCasa.AutoSize = true;
            this.lbl_EquipaCasa.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EquipaCasa.Location = new System.Drawing.Point(144, 289);
            this.lbl_EquipaCasa.Name = "lbl_EquipaCasa";
            this.lbl_EquipaCasa.Size = new System.Drawing.Size(34, 15);
            this.lbl_EquipaCasa.TabIndex = 35;
            this.lbl_EquipaCasa.Text = "teste";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Berlin Sans FB Demi", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(41, 307);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 18);
            this.label5.TabIndex = 38;
            this.label5.Text = "Golos:";
            // 
            // lbl_GolosCasa
            // 
            this.lbl_GolosCasa.AutoSize = true;
            this.lbl_GolosCasa.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_GolosCasa.Location = new System.Drawing.Point(98, 310);
            this.lbl_GolosCasa.Name = "lbl_GolosCasa";
            this.lbl_GolosCasa.Size = new System.Drawing.Size(34, 15);
            this.lbl_GolosCasa.TabIndex = 37;
            this.lbl_GolosCasa.Text = "teste";
            // 
            // img_LogoCasa
            // 
            this.img_LogoCasa.Location = new System.Drawing.Point(95, 166);
            this.img_LogoCasa.Name = "img_LogoCasa";
            this.img_LogoCasa.Size = new System.Drawing.Size(100, 100);
            this.img_LogoCasa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.img_LogoCasa.TabIndex = 39;
            this.img_LogoCasa.TabStop = false;
            // 
            // img_LogoFora
            // 
            this.img_LogoFora.Location = new System.Drawing.Point(353, 166);
            this.img_LogoFora.Name = "img_LogoFora";
            this.img_LogoFora.Size = new System.Drawing.Size(100, 100);
            this.img_LogoFora.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.img_LogoFora.TabIndex = 40;
            this.img_LogoFora.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Berlin Sans FB Demi", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(306, 307);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 18);
            this.label4.TabIndex = 44;
            this.label4.Text = "Golos:";
            // 
            // lbl_GolosFora
            // 
            this.lbl_GolosFora.AutoSize = true;
            this.lbl_GolosFora.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_GolosFora.Location = new System.Drawing.Point(363, 310);
            this.lbl_GolosFora.Name = "lbl_GolosFora";
            this.lbl_GolosFora.Size = new System.Drawing.Size(34, 15);
            this.lbl_GolosFora.TabIndex = 43;
            this.lbl_GolosFora.Text = "teste";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Berlin Sans FB Demi", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(306, 286);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 18);
            this.label7.TabIndex = 42;
            this.label7.Text = "Equipa Fora:";
            // 
            // lbl_EquipaFora
            // 
            this.lbl_EquipaFora.AutoSize = true;
            this.lbl_EquipaFora.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EquipaFora.Location = new System.Drawing.Point(408, 289);
            this.lbl_EquipaFora.Name = "lbl_EquipaFora";
            this.lbl_EquipaFora.Size = new System.Drawing.Size(34, 15);
            this.lbl_EquipaFora.TabIndex = 41;
            this.lbl_EquipaFora.Text = "teste";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Berlin Sans FB Demi", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(350, 95);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 18);
            this.label9.TabIndex = 46;
            this.label9.Text = "Divisão:";
            // 
            // lbl_Divisao
            // 
            this.lbl_Divisao.AutoSize = true;
            this.lbl_Divisao.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Divisao.Location = new System.Drawing.Point(419, 98);
            this.lbl_Divisao.Name = "lbl_Divisao";
            this.lbl_Divisao.Size = new System.Drawing.Size(34, 15);
            this.lbl_Divisao.TabIndex = 45;
            this.lbl_Divisao.Text = "teste";
            // 
            // flowpanel_Golos
            // 
            this.flowpanel_Golos.AutoScroll = true;
            this.flowpanel_Golos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowpanel_Golos.Location = new System.Drawing.Point(27, 389);
            this.flowpanel_Golos.Name = "flowpanel_Golos";
            this.flowpanel_Golos.Size = new System.Drawing.Size(491, 152);
            this.flowpanel_Golos.TabIndex = 47;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Berlin Sans FB Demi", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(24, 368);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(171, 18);
            this.label10.TabIndex = 48;
            this.label10.Text = "Golos Palmelense F.C. :";
            // 
            // VerJogo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(544, 611);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.flowpanel_Golos);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lbl_Divisao);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbl_GolosFora);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbl_EquipaFora);
            this.Controls.Add(this.img_LogoFora);
            this.Controls.Add(this.img_LogoCasa);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbl_GolosCasa);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbl_EquipaCasa);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_Escalao);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_Data);
            this.Controls.Add(this.btn_Fechar);
            this.Controls.Add(this.lbl_Titulo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "VerJogo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Jogo";
            this.Load += new System.EventHandler(this.VerJogo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.img_LogoCasa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_LogoFora)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Titulo;
        private System.Windows.Forms.Button btn_Fechar;
        private System.Windows.Forms.Label lbl_Data;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_Escalao;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_EquipaCasa;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbl_GolosCasa;
        private System.Windows.Forms.PictureBox img_LogoCasa;
        private System.Windows.Forms.PictureBox img_LogoFora;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_GolosFora;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_EquipaFora;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbl_Divisao;
        private System.Windows.Forms.FlowLayoutPanel flowpanel_Golos;
        private System.Windows.Forms.Label label10;
    }
}