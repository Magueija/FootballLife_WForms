﻿namespace FootballLife_WF
{
    partial class NovaConvocatoria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NovaConvocatoria));
            this.lbl_Titulo = new System.Windows.Forms.Label();
            this.rb_451 = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_Adversario = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_Hora = new System.Windows.Forms.TextBox();
            this.rb_433 = new System.Windows.Forms.RadioButton();
            this.rb_343 = new System.Windows.Forms.RadioButton();
            this.rb_442 = new System.Windows.Forms.RadioButton();
            this.rb_352 = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.P1 = new System.Windows.Forms.Label();
            this.P2 = new System.Windows.Forms.Label();
            this.P3 = new System.Windows.Forms.Label();
            this.P4 = new System.Windows.Forms.Label();
            this.P5 = new System.Windows.Forms.Label();
            this.P6 = new System.Windows.Forms.Label();
            this.P7 = new System.Windows.Forms.Label();
            this.P8 = new System.Windows.Forms.Label();
            this.P9 = new System.Windows.Forms.Label();
            this.P10 = new System.Windows.Forms.Label();
            this.P11 = new System.Windows.Forms.Label();
            this.flowpanel_Titulares = new System.Windows.Forms.FlowLayoutPanel();
            this.flowpanel_Suplentes = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_Gravar = new System.Windows.Forms.Button();
            this.lbl_LoginError = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.dt_Data = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // lbl_Titulo
            // 
            this.lbl_Titulo.AutoSize = true;
            this.lbl_Titulo.Font = new System.Drawing.Font("Bauhaus 93", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Titulo.Location = new System.Drawing.Point(191, 32);
            this.lbl_Titulo.Name = "lbl_Titulo";
            this.lbl_Titulo.Size = new System.Drawing.Size(187, 21);
            this.lbl_Titulo.TabIndex = 4;
            this.lbl_Titulo.Text = "Nova Convocatória";
            // 
            // rb_451
            // 
            this.rb_451.AutoSize = true;
            this.rb_451.Checked = true;
            this.rb_451.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_451.Location = new System.Drawing.Point(85, 222);
            this.rb_451.Name = "rb_451";
            this.rb_451.Size = new System.Drawing.Size(52, 19);
            this.rb_451.TabIndex = 19;
            this.rb_451.TabStop = true;
            this.rb_451.Tag = "";
            this.rb_451.Text = "4-5-1";
            this.rb_451.UseVisualStyleBackColor = true;
            this.rb_451.CheckedChanged += new System.EventHandler(this.Rb_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(24, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 16);
            this.label2.TabIndex = 22;
            this.label2.Text = "Data do Jogo:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(28, 154);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 16);
            this.label1.TabIndex = 24;
            this.label1.Text = "Adversário:";
            // 
            // tb_Adversario
            // 
            this.tb_Adversario.Font = new System.Drawing.Font("Arial", 9.75F);
            this.tb_Adversario.Location = new System.Drawing.Point(107, 151);
            this.tb_Adversario.Name = "tb_Adversario";
            this.tb_Adversario.Size = new System.Drawing.Size(235, 22);
            this.tb_Adversario.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(311, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 16);
            this.label3.TabIndex = 26;
            this.label3.Text = "Hora do Jogo:";
            // 
            // tb_Hora
            // 
            this.tb_Hora.Font = new System.Drawing.Font("Arial", 9.75F);
            this.tb_Hora.Location = new System.Drawing.Point(409, 109);
            this.tb_Hora.Name = "tb_Hora";
            this.tb_Hora.Size = new System.Drawing.Size(98, 22);
            this.tb_Hora.TabIndex = 25;
            this.tb_Hora.Text = "HH:MM";
            this.tb_Hora.Click += new System.EventHandler(this.Tb_Hora_Click);
            this.tb_Hora.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Tb_Hora_KeyDown);
            // 
            // rb_433
            // 
            this.rb_433.AutoSize = true;
            this.rb_433.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_433.Location = new System.Drawing.Point(153, 222);
            this.rb_433.Name = "rb_433";
            this.rb_433.Size = new System.Drawing.Size(54, 19);
            this.rb_433.TabIndex = 20;
            this.rb_433.Tag = "";
            this.rb_433.Text = "4-3-3";
            this.rb_433.UseVisualStyleBackColor = true;
            this.rb_433.CheckedChanged += new System.EventHandler(this.Rb_CheckedChanged);
            // 
            // rb_343
            // 
            this.rb_343.AutoSize = true;
            this.rb_343.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_343.Location = new System.Drawing.Point(363, 222);
            this.rb_343.Name = "rb_343";
            this.rb_343.Size = new System.Drawing.Size(54, 19);
            this.rb_343.TabIndex = 27;
            this.rb_343.Tag = "";
            this.rb_343.Text = "3-4-3";
            this.rb_343.UseVisualStyleBackColor = true;
            this.rb_343.CheckedChanged += new System.EventHandler(this.Rb_CheckedChanged);
            // 
            // rb_442
            // 
            this.rb_442.AutoSize = true;
            this.rb_442.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_442.Location = new System.Drawing.Point(223, 222);
            this.rb_442.Name = "rb_442";
            this.rb_442.Size = new System.Drawing.Size(55, 19);
            this.rb_442.TabIndex = 28;
            this.rb_442.Tag = "";
            this.rb_442.Text = "4-4-2";
            this.rb_442.UseVisualStyleBackColor = true;
            this.rb_442.CheckedChanged += new System.EventHandler(this.Rb_CheckedChanged);
            // 
            // rb_352
            // 
            this.rb_352.AutoSize = true;
            this.rb_352.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_352.Location = new System.Drawing.Point(294, 222);
            this.rb_352.Name = "rb_352";
            this.rb_352.Size = new System.Drawing.Size(53, 19);
            this.rb_352.TabIndex = 29;
            this.rb_352.Tag = "";
            this.rb_352.Text = "3-5-2";
            this.rb_352.UseVisualStyleBackColor = true;
            this.rb_352.CheckedChanged += new System.EventHandler(this.Rb_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(28, 223);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 16);
            this.label4.TabIndex = 30;
            this.label4.Text = "Tática:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(29, 305);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 16);
            this.label5.TabIndex = 31;
            this.label5.Text = "Titulares:";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(31, 324);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(213, 1);
            this.panel1.TabIndex = 32;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(315, 324);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(160, 1);
            this.panel2.TabIndex = 34;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(313, 305);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 16);
            this.label6.TabIndex = 33;
            this.label6.Text = "Suplentes:";
            // 
            // P1
            // 
            this.P1.AutoSize = true;
            this.P1.Font = new System.Drawing.Font("Cooper Black", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P1.ForeColor = System.Drawing.Color.ForestGreen;
            this.P1.Location = new System.Drawing.Point(29, 331);
            this.P1.Name = "P1";
            this.P1.Size = new System.Drawing.Size(32, 17);
            this.P1.TabIndex = 36;
            this.P1.Text = "GR";
            // 
            // P2
            // 
            this.P2.AutoSize = true;
            this.P2.Font = new System.Drawing.Font("Cooper Black", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P2.ForeColor = System.Drawing.Color.DarkBlue;
            this.P2.Location = new System.Drawing.Point(29, 362);
            this.P2.Name = "P2";
            this.P2.Size = new System.Drawing.Size(31, 17);
            this.P2.TabIndex = 47;
            this.P2.Text = "DC";
            // 
            // P3
            // 
            this.P3.AutoSize = true;
            this.P3.Font = new System.Drawing.Font("Cooper Black", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P3.ForeColor = System.Drawing.Color.DarkBlue;
            this.P3.Location = new System.Drawing.Point(29, 391);
            this.P3.Name = "P3";
            this.P3.Size = new System.Drawing.Size(31, 17);
            this.P3.TabIndex = 57;
            this.P3.Text = "DC";
            // 
            // P4
            // 
            this.P4.AutoSize = true;
            this.P4.Font = new System.Drawing.Font("Cooper Black", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P4.ForeColor = System.Drawing.Color.DarkBlue;
            this.P4.Location = new System.Drawing.Point(29, 419);
            this.P4.Name = "P4";
            this.P4.Size = new System.Drawing.Size(30, 17);
            this.P4.TabIndex = 58;
            this.P4.Text = "DE";
            // 
            // P5
            // 
            this.P5.AutoSize = true;
            this.P5.Font = new System.Drawing.Font("Cooper Black", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P5.ForeColor = System.Drawing.Color.DarkBlue;
            this.P5.Location = new System.Drawing.Point(29, 447);
            this.P5.Name = "P5";
            this.P5.Size = new System.Drawing.Size(32, 17);
            this.P5.TabIndex = 59;
            this.P5.Text = "DD";
            // 
            // P6
            // 
            this.P6.AutoSize = true;
            this.P6.Font = new System.Drawing.Font("Cooper Black", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P6.ForeColor = System.Drawing.Color.Gold;
            this.P6.Location = new System.Drawing.Point(29, 476);
            this.P6.Name = "P6";
            this.P6.Size = new System.Drawing.Size(44, 17);
            this.P6.TabIndex = 60;
            this.P6.Text = "MDC";
            // 
            // P7
            // 
            this.P7.AutoSize = true;
            this.P7.Font = new System.Drawing.Font("Cooper Black", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P7.ForeColor = System.Drawing.Color.Gold;
            this.P7.Location = new System.Drawing.Point(29, 505);
            this.P7.Name = "P7";
            this.P7.Size = new System.Drawing.Size(32, 17);
            this.P7.TabIndex = 61;
            this.P7.Text = "MC";
            // 
            // P8
            // 
            this.P8.AutoSize = true;
            this.P8.Font = new System.Drawing.Font("Cooper Black", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P8.ForeColor = System.Drawing.Color.Gold;
            this.P8.Location = new System.Drawing.Point(29, 533);
            this.P8.Name = "P8";
            this.P8.Size = new System.Drawing.Size(32, 17);
            this.P8.TabIndex = 62;
            this.P8.Text = "MC";
            // 
            // P9
            // 
            this.P9.AutoSize = true;
            this.P9.Font = new System.Drawing.Font("Cooper Black", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P9.ForeColor = System.Drawing.Color.Gold;
            this.P9.Location = new System.Drawing.Point(29, 563);
            this.P9.Name = "P9";
            this.P9.Size = new System.Drawing.Size(43, 17);
            this.P9.TabIndex = 63;
            this.P9.Text = "MOE";
            // 
            // P10
            // 
            this.P10.AutoSize = true;
            this.P10.Font = new System.Drawing.Font("Cooper Black", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P10.ForeColor = System.Drawing.Color.Gold;
            this.P10.Location = new System.Drawing.Point(29, 593);
            this.P10.Name = "P10";
            this.P10.Size = new System.Drawing.Size(43, 17);
            this.P10.TabIndex = 64;
            this.P10.Text = "MOE";
            // 
            // P11
            // 
            this.P11.AutoSize = true;
            this.P11.Font = new System.Drawing.Font("Cooper Black", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P11.ForeColor = System.Drawing.Color.Firebrick;
            this.P11.Location = new System.Drawing.Point(29, 621);
            this.P11.Name = "P11";
            this.P11.Size = new System.Drawing.Size(28, 17);
            this.P11.TabIndex = 65;
            this.P11.Text = "PL";
            // 
            // flowpanel_Titulares
            // 
            this.flowpanel_Titulares.Location = new System.Drawing.Point(78, 325);
            this.flowpanel_Titulares.Name = "flowpanel_Titulares";
            this.flowpanel_Titulares.Size = new System.Drawing.Size(174, 332);
            this.flowpanel_Titulares.TabIndex = 66;
            // 
            // flowpanel_Suplentes
            // 
            this.flowpanel_Suplentes.Location = new System.Drawing.Point(312, 325);
            this.flowpanel_Suplentes.Name = "flowpanel_Suplentes";
            this.flowpanel_Suplentes.Size = new System.Drawing.Size(163, 235);
            this.flowpanel_Suplentes.TabIndex = 67;
            // 
            // btn_Gravar
            // 
            this.btn_Gravar.BackColor = System.Drawing.Color.White;
            this.btn_Gravar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Gravar.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn_Gravar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Gravar.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Gravar.ForeColor = System.Drawing.Color.Black;
            this.btn_Gravar.Location = new System.Drawing.Point(438, 623);
            this.btn_Gravar.Name = "btn_Gravar";
            this.btn_Gravar.Size = new System.Drawing.Size(92, 34);
            this.btn_Gravar.TabIndex = 29;
            this.btn_Gravar.Text = "Gravar";
            this.btn_Gravar.UseVisualStyleBackColor = false;
            this.btn_Gravar.Click += new System.EventHandler(this.Btn_Gravar_Click);
            // 
            // lbl_LoginError
            // 
            this.lbl_LoginError.AutoSize = true;
            this.lbl_LoginError.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_LoginError.ForeColor = System.Drawing.Color.Firebrick;
            this.lbl_LoginError.Location = new System.Drawing.Point(379, 91);
            this.lbl_LoginError.Name = "lbl_LoginError";
            this.lbl_LoginError.Size = new System.Drawing.Size(128, 15);
            this.lbl_LoginError.TabIndex = 68;
            this.lbl_LoginError.Text = "* Campos Obrigatórios!";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Firebrick;
            this.label7.Location = new System.Drawing.Point(507, 110);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(12, 15);
            this.label7.TabIndex = 69;
            this.label7.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Firebrick;
            this.label8.Location = new System.Drawing.Point(342, 152);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(12, 15);
            this.label8.TabIndex = 70;
            this.label8.Text = "*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Firebrick;
            this.label9.Location = new System.Drawing.Point(279, 113);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(12, 15);
            this.label9.TabIndex = 71;
            this.label9.Text = "*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Firebrick;
            this.label10.Location = new System.Drawing.Point(69, 224);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(12, 15);
            this.label10.TabIndex = 72;
            this.label10.Text = "*";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Firebrick;
            this.label11.Location = new System.Drawing.Point(84, 306);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(12, 15);
            this.label11.TabIndex = 73;
            this.label11.Text = "*";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Firebrick;
            this.label12.Location = new System.Drawing.Point(373, 306);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(12, 15);
            this.label12.TabIndex = 74;
            this.label12.Text = "*";
            // 
            // dt_Data
            // 
            this.dt_Data.Location = new System.Drawing.Point(118, 113);
            this.dt_Data.Name = "dt_Data";
            this.dt_Data.Size = new System.Drawing.Size(162, 20);
            this.dt_Data.TabIndex = 75;
            // 
            // NovaConvocatoria
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(542, 669);
            this.Controls.Add(this.dt_Data);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbl_LoginError);
            this.Controls.Add(this.btn_Gravar);
            this.Controls.Add(this.flowpanel_Suplentes);
            this.Controls.Add(this.flowpanel_Titulares);
            this.Controls.Add(this.P11);
            this.Controls.Add(this.P10);
            this.Controls.Add(this.P9);
            this.Controls.Add(this.P8);
            this.Controls.Add(this.P7);
            this.Controls.Add(this.P6);
            this.Controls.Add(this.P5);
            this.Controls.Add(this.P4);
            this.Controls.Add(this.P3);
            this.Controls.Add(this.P2);
            this.Controls.Add(this.P1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.rb_352);
            this.Controls.Add(this.rb_442);
            this.Controls.Add(this.rb_343);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tb_Hora);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_Adversario);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.rb_433);
            this.Controls.Add(this.rb_451);
            this.Controls.Add(this.lbl_Titulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "NovaConvocatoria";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Nova Convocatoria";
            this.Load += new System.EventHandler(this.NovaConvocatoria_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Titulo;
        private System.Windows.Forms.RadioButton rb_451;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_Adversario;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_Hora;
        private System.Windows.Forms.RadioButton rb_433;
        private System.Windows.Forms.RadioButton rb_343;
        private System.Windows.Forms.RadioButton rb_442;
        private System.Windows.Forms.RadioButton rb_352;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label P1;
        private System.Windows.Forms.Label P2;
        private System.Windows.Forms.Label P3;
        private System.Windows.Forms.Label P4;
        private System.Windows.Forms.Label P5;
        private System.Windows.Forms.Label P6;
        private System.Windows.Forms.Label P7;
        private System.Windows.Forms.Label P8;
        private System.Windows.Forms.Label P9;
        private System.Windows.Forms.Label P10;
        private System.Windows.Forms.Label P11;
        private System.Windows.Forms.FlowLayoutPanel flowpanel_Titulares;
        private System.Windows.Forms.FlowLayoutPanel flowpanel_Suplentes;
        private System.Windows.Forms.Button btn_Gravar;
        private System.Windows.Forms.Label lbl_LoginError;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DateTimePicker dt_Data;
    }
}