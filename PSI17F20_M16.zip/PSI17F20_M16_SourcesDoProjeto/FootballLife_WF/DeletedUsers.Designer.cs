﻿namespace FootballLife_WF
{
    partial class DeletedUsers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DeletedUsers));
            this.lbl_Admins = new System.Windows.Forms.Label();
            this.flowpanel_Admins = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.flowpanel_Treinadores = new System.Windows.Forms.FlowLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.flowpanel_Atletas = new System.Windows.Forms.FlowLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.flowpanel_Socios = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_Fechar = new System.Windows.Forms.Button();
            this.panel_Pesquisa = new System.Windows.Forms.Panel();
            this.btn_Lupa = new System.Windows.Forms.Button();
            this.btn_DeletePesquisa = new System.Windows.Forms.Button();
            this.tb_Pesquisar = new System.Windows.Forms.TextBox();
            this.lbl_Pesquisar = new System.Windows.Forms.Label();
            this.lbl_Titulo = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.panel_Pesquisa.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_Admins
            // 
            this.lbl_Admins.AutoSize = true;
            this.lbl_Admins.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Admins.Cursor = System.Windows.Forms.Cursors.Default;
            this.lbl_Admins.Font = new System.Drawing.Font("Berlin Sans FB Demi", 10F, System.Drawing.FontStyle.Bold);
            this.lbl_Admins.ForeColor = System.Drawing.Color.Black;
            this.lbl_Admins.Location = new System.Drawing.Point(41, 204);
            this.lbl_Admins.Name = "lbl_Admins";
            this.lbl_Admins.Size = new System.Drawing.Size(128, 18);
            this.lbl_Admins.TabIndex = 28;
            this.lbl_Admins.Text = "ADMINISTRADORES";
            // 
            // flowpanel_Admins
            // 
            this.flowpanel_Admins.AutoScroll = true;
            this.flowpanel_Admins.BackColor = System.Drawing.Color.Transparent;
            this.flowpanel_Admins.Location = new System.Drawing.Point(44, 234);
            this.flowpanel_Admins.Name = "flowpanel_Admins";
            this.flowpanel_Admins.Size = new System.Drawing.Size(257, 219);
            this.flowpanel_Admins.TabIndex = 30;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Cursor = System.Windows.Forms.Cursors.Default;
            this.label1.Font = new System.Drawing.Font("Berlin Sans FB Demi", 10F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(337, 204);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 18);
            this.label1.TabIndex = 31;
            this.label1.Text = "TREINADORES";
            // 
            // flowpanel_Treinadores
            // 
            this.flowpanel_Treinadores.AutoScroll = true;
            this.flowpanel_Treinadores.BackColor = System.Drawing.Color.Transparent;
            this.flowpanel_Treinadores.Location = new System.Drawing.Point(340, 234);
            this.flowpanel_Treinadores.Name = "flowpanel_Treinadores";
            this.flowpanel_Treinadores.Size = new System.Drawing.Size(257, 219);
            this.flowpanel_Treinadores.TabIndex = 32;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Cursor = System.Windows.Forms.Cursors.Default;
            this.label2.Font = new System.Drawing.Font("Berlin Sans FB Demi", 10F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(41, 517);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 18);
            this.label2.TabIndex = 33;
            this.label2.Text = "ATLETAS";
            // 
            // flowpanel_Atletas
            // 
            this.flowpanel_Atletas.AutoScroll = true;
            this.flowpanel_Atletas.BackColor = System.Drawing.Color.Transparent;
            this.flowpanel_Atletas.Location = new System.Drawing.Point(44, 547);
            this.flowpanel_Atletas.Name = "flowpanel_Atletas";
            this.flowpanel_Atletas.Size = new System.Drawing.Size(257, 219);
            this.flowpanel_Atletas.TabIndex = 34;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Cursor = System.Windows.Forms.Cursors.Default;
            this.label3.Font = new System.Drawing.Font("Berlin Sans FB Demi", 10F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(337, 517);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 18);
            this.label3.TabIndex = 35;
            this.label3.Text = "SÓCIOS";
            // 
            // flowpanel_Socios
            // 
            this.flowpanel_Socios.AutoScroll = true;
            this.flowpanel_Socios.BackColor = System.Drawing.Color.Transparent;
            this.flowpanel_Socios.Location = new System.Drawing.Point(340, 547);
            this.flowpanel_Socios.Name = "flowpanel_Socios";
            this.flowpanel_Socios.Size = new System.Drawing.Size(257, 219);
            this.flowpanel_Socios.TabIndex = 36;
            // 
            // btn_Fechar
            // 
            this.btn_Fechar.BackColor = System.Drawing.Color.White;
            this.btn_Fechar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Fechar.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn_Fechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Fechar.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Fechar.ForeColor = System.Drawing.Color.Black;
            this.btn_Fechar.Location = new System.Drawing.Point(531, 812);
            this.btn_Fechar.Name = "btn_Fechar";
            this.btn_Fechar.Size = new System.Drawing.Size(100, 29);
            this.btn_Fechar.TabIndex = 37;
            this.btn_Fechar.Text = "Fechar";
            this.btn_Fechar.UseVisualStyleBackColor = false;
            this.btn_Fechar.Click += new System.EventHandler(this.Btn_Fechar_Click);
            // 
            // panel_Pesquisa
            // 
            this.panel_Pesquisa.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel_Pesquisa.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel_Pesquisa.Controls.Add(this.btn_Lupa);
            this.panel_Pesquisa.Controls.Add(this.btn_DeletePesquisa);
            this.panel_Pesquisa.Controls.Add(this.tb_Pesquisar);
            this.panel_Pesquisa.Controls.Add(this.lbl_Pesquisar);
            this.panel_Pesquisa.Location = new System.Drawing.Point(44, 118);
            this.panel_Pesquisa.Name = "panel_Pesquisa";
            this.panel_Pesquisa.Size = new System.Drawing.Size(553, 45);
            this.panel_Pesquisa.TabIndex = 38;
            // 
            // btn_Lupa
            // 
            this.btn_Lupa.BackColor = System.Drawing.Color.White;
            this.btn_Lupa.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Lupa.BackgroundImage")));
            this.btn_Lupa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Lupa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Lupa.FlatAppearance.BorderSize = 0;
            this.btn_Lupa.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_Lupa.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_Lupa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Lupa.Location = new System.Drawing.Point(516, 13);
            this.btn_Lupa.Name = "btn_Lupa";
            this.btn_Lupa.Size = new System.Drawing.Size(17, 17);
            this.btn_Lupa.TabIndex = 29;
            this.btn_Lupa.UseVisualStyleBackColor = false;
            this.btn_Lupa.Click += new System.EventHandler(this.Btn_Lupa_Click);
            // 
            // btn_DeletePesquisa
            // 
            this.btn_DeletePesquisa.BackColor = System.Drawing.Color.White;
            this.btn_DeletePesquisa.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_DeletePesquisa.BackgroundImage")));
            this.btn_DeletePesquisa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_DeletePesquisa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_DeletePesquisa.FlatAppearance.BorderSize = 0;
            this.btn_DeletePesquisa.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_DeletePesquisa.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_DeletePesquisa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_DeletePesquisa.Location = new System.Drawing.Point(501, 16);
            this.btn_DeletePesquisa.Name = "btn_DeletePesquisa";
            this.btn_DeletePesquisa.Size = new System.Drawing.Size(9, 9);
            this.btn_DeletePesquisa.TabIndex = 28;
            this.btn_DeletePesquisa.UseVisualStyleBackColor = false;
            this.btn_DeletePesquisa.Click += new System.EventHandler(this.Btn_DeletePesquisa_Click);
            // 
            // tb_Pesquisar
            // 
            this.tb_Pesquisar.Font = new System.Drawing.Font("Arial", 9.75F);
            this.tb_Pesquisar.Location = new System.Drawing.Point(134, 10);
            this.tb_Pesquisar.Name = "tb_Pesquisar";
            this.tb_Pesquisar.Size = new System.Drawing.Size(402, 22);
            this.tb_Pesquisar.TabIndex = 26;
            this.tb_Pesquisar.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_KeyDown);
            // 
            // lbl_Pesquisar
            // 
            this.lbl_Pesquisar.AutoSize = true;
            this.lbl_Pesquisar.Font = new System.Drawing.Font("Berlin Sans FB Demi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Pesquisar.Location = new System.Drawing.Point(19, 11);
            this.lbl_Pesquisar.Name = "lbl_Pesquisar";
            this.lbl_Pesquisar.Size = new System.Drawing.Size(109, 18);
            this.lbl_Pesquisar.TabIndex = 25;
            this.lbl_Pesquisar.Text = "Pesquisar Por:";
            // 
            // lbl_Titulo
            // 
            this.lbl_Titulo.AutoSize = true;
            this.lbl_Titulo.Font = new System.Drawing.Font("Bauhaus 93", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Titulo.Location = new System.Drawing.Point(204, 50);
            this.lbl_Titulo.Name = "lbl_Titulo";
            this.lbl_Titulo.Size = new System.Drawing.Size(231, 21);
            this.lbl_Titulo.TabIndex = 39;
            this.lbl_Titulo.Text = "Utilizadores Eliminados";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(44, 223);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(257, 1);
            this.panel1.TabIndex = 40;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(340, 223);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(257, 1);
            this.panel2.TabIndex = 41;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Location = new System.Drawing.Point(44, 538);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(257, 1);
            this.panel3.TabIndex = 42;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Location = new System.Drawing.Point(340, 538);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(257, 1);
            this.panel4.TabIndex = 41;
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl1.Location = new System.Drawing.Point(45, 245);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(237, 15);
            this.lbl1.TabIndex = 43;
            this.lbl1.Text = "Sem resultados para os criterios da pesquisa!";
            this.lbl1.Visible = false;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl2.Location = new System.Drawing.Point(342, 245);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(237, 15);
            this.lbl2.TabIndex = 44;
            this.lbl2.Text = "Sem resultados para os criterios da pesquisa!";
            this.lbl2.Visible = false;
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl3.Location = new System.Drawing.Point(46, 562);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(237, 15);
            this.lbl3.TabIndex = 45;
            this.lbl3.Text = "Sem resultados para os criterios da pesquisa!";
            this.lbl3.Visible = false;
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl4.Location = new System.Drawing.Point(342, 562);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(237, 15);
            this.lbl4.TabIndex = 46;
            this.lbl4.Text = "Sem resultados para os criterios da pesquisa!";
            this.lbl4.Visible = false;
            // 
            // DeletedUsers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(643, 853);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lbl_Titulo);
            this.Controls.Add(this.panel_Pesquisa);
            this.Controls.Add(this.btn_Fechar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.flowpanel_Socios);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.flowpanel_Atletas);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.flowpanel_Treinadores);
            this.Controls.Add(this.lbl_Admins);
            this.Controls.Add(this.flowpanel_Admins);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DeletedUsers";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Utilizadores Apagados";
            this.Load += new System.EventHandler(this.DeletedUsers_Load);
            this.panel_Pesquisa.ResumeLayout(false);
            this.panel_Pesquisa.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Admins;
        private System.Windows.Forms.FlowLayoutPanel flowpanel_Admins;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FlowLayoutPanel flowpanel_Treinadores;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.FlowLayoutPanel flowpanel_Atletas;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.FlowLayoutPanel flowpanel_Socios;
        private System.Windows.Forms.Button btn_Fechar;
        private System.Windows.Forms.Panel panel_Pesquisa;
        private System.Windows.Forms.Button btn_Lupa;
        private System.Windows.Forms.Button btn_DeletePesquisa;
        private System.Windows.Forms.TextBox tb_Pesquisar;
        private System.Windows.Forms.Label lbl_Pesquisar;
        private System.Windows.Forms.Label lbl_Titulo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl4;
    }
}