﻿namespace FootballLife_WF
{
    partial class Estadio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Estadio));
            this.img_Menu = new System.Windows.Forms.PictureBox();
            this.img_Logo = new System.Windows.Forms.PictureBox();
            this.btn_TopMenu = new System.Windows.Forms.Button();
            this.btn_Titulos = new System.Windows.Forms.Button();
            this.btn_Estadio = new System.Windows.Forms.Button();
            this.btn_Equipas = new System.Windows.Forms.Button();
            this.btn_Jogos = new System.Windows.Forms.Button();
            this.btn_Home = new System.Windows.Forms.Button();
            this.panel_Menu = new System.Windows.Forms.Panel();
            this.lbl_Sessao = new System.Windows.Forms.Label();
            this.btn3 = new System.Windows.Forms.Button();
            this.lbl_Terminar = new System.Windows.Forms.Label();
            this.img_LogOut = new System.Windows.Forms.PictureBox();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn_LogOut = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.lbl_Titulo = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.img_Menu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_Logo)).BeginInit();
            this.panel_Menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.img_LogOut)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.SuspendLayout();
            // 
            // img_Menu
            // 
            this.img_Menu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.img_Menu.BackColor = System.Drawing.Color.Transparent;
            this.img_Menu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.img_Menu.Image = global::FootballLife_WF.Properties.Resources.MenuWhite;
            this.img_Menu.Location = new System.Drawing.Point(12, 16);
            this.img_Menu.MaximumSize = new System.Drawing.Size(32, 32);
            this.img_Menu.MinimumSize = new System.Drawing.Size(32, 32);
            this.img_Menu.Name = "img_Menu";
            this.img_Menu.Size = new System.Drawing.Size(32, 32);
            this.img_Menu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.img_Menu.TabIndex = 2;
            this.img_Menu.TabStop = false;
            this.img_Menu.Click += new System.EventHandler(this.Img_Menu_Click);
            // 
            // img_Logo
            // 
            this.img_Logo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.img_Logo.BackColor = System.Drawing.Color.Transparent;
            this.img_Logo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.img_Logo.Image = global::FootballLife_WF.Properties.Resources.Logo_Clube;
            this.img_Logo.Location = new System.Drawing.Point(1291, 12);
            this.img_Logo.MaximumSize = new System.Drawing.Size(44, 40);
            this.img_Logo.MinimumSize = new System.Drawing.Size(44, 40);
            this.img_Logo.Name = "img_Logo";
            this.img_Logo.Size = new System.Drawing.Size(44, 40);
            this.img_Logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.img_Logo.TabIndex = 3;
            this.img_Logo.TabStop = false;
            this.img_Logo.Click += new System.EventHandler(this.Btn_Home_Click);
            // 
            // btn_TopMenu
            // 
            this.btn_TopMenu.BackColor = System.Drawing.Color.Transparent;
            this.btn_TopMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_TopMenu.Enabled = false;
            this.btn_TopMenu.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_TopMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_TopMenu.Location = new System.Drawing.Point(0, 0);
            this.btn_TopMenu.Name = "btn_TopMenu";
            this.btn_TopMenu.Size = new System.Drawing.Size(1347, 65);
            this.btn_TopMenu.TabIndex = 0;
            this.btn_TopMenu.UseVisualStyleBackColor = false;
            // 
            // btn_Titulos
            // 
            this.btn_Titulos.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Titulos.BackColor = System.Drawing.Color.Black;
            this.btn_Titulos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Titulos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Titulos.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Titulos.ForeColor = System.Drawing.Color.White;
            this.btn_Titulos.Location = new System.Drawing.Point(12, 194);
            this.btn_Titulos.Name = "btn_Titulos";
            this.btn_Titulos.Size = new System.Drawing.Size(128, 31);
            this.btn_Titulos.TabIndex = 9;
            this.btn_Titulos.Text = "HISTÓRIA";
            this.btn_Titulos.UseVisualStyleBackColor = false;
            this.btn_Titulos.Click += new System.EventHandler(this.Btn_Titulos_Click);
            // 
            // btn_Estadio
            // 
            this.btn_Estadio.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Estadio.BackColor = System.Drawing.Color.Black;
            this.btn_Estadio.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Estadio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Estadio.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Estadio.ForeColor = System.Drawing.Color.White;
            this.btn_Estadio.Location = new System.Drawing.Point(12, 157);
            this.btn_Estadio.Name = "btn_Estadio";
            this.btn_Estadio.Size = new System.Drawing.Size(128, 31);
            this.btn_Estadio.TabIndex = 8;
            this.btn_Estadio.Text = "ESTÁDIO";
            this.btn_Estadio.UseVisualStyleBackColor = false;
            // 
            // btn_Equipas
            // 
            this.btn_Equipas.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Equipas.BackColor = System.Drawing.Color.Black;
            this.btn_Equipas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Equipas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Equipas.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Equipas.ForeColor = System.Drawing.Color.White;
            this.btn_Equipas.Location = new System.Drawing.Point(12, 120);
            this.btn_Equipas.Name = "btn_Equipas";
            this.btn_Equipas.Size = new System.Drawing.Size(128, 31);
            this.btn_Equipas.TabIndex = 7;
            this.btn_Equipas.Text = "EQUIPAS";
            this.btn_Equipas.UseVisualStyleBackColor = false;
            this.btn_Equipas.Click += new System.EventHandler(this.Btn_Equipas_Click);
            // 
            // btn_Jogos
            // 
            this.btn_Jogos.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Jogos.BackColor = System.Drawing.Color.Black;
            this.btn_Jogos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Jogos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Jogos.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Jogos.ForeColor = System.Drawing.Color.White;
            this.btn_Jogos.Location = new System.Drawing.Point(12, 83);
            this.btn_Jogos.Name = "btn_Jogos";
            this.btn_Jogos.Size = new System.Drawing.Size(128, 31);
            this.btn_Jogos.TabIndex = 6;
            this.btn_Jogos.Text = "JOGOS";
            this.btn_Jogos.UseVisualStyleBackColor = false;
            this.btn_Jogos.Click += new System.EventHandler(this.Btn_Jogos_Click);
            // 
            // btn_Home
            // 
            this.btn_Home.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Home.BackColor = System.Drawing.Color.Black;
            this.btn_Home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Home.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Home.ForeColor = System.Drawing.Color.White;
            this.btn_Home.Location = new System.Drawing.Point(12, 32);
            this.btn_Home.Name = "btn_Home";
            this.btn_Home.Size = new System.Drawing.Size(128, 31);
            this.btn_Home.TabIndex = 5;
            this.btn_Home.Text = "HOME";
            this.btn_Home.UseVisualStyleBackColor = false;
            this.btn_Home.Click += new System.EventHandler(this.Btn_Home_Click);
            // 
            // panel_Menu
            // 
            this.panel_Menu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel_Menu.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel_Menu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_Menu.Controls.Add(this.lbl_Sessao);
            this.panel_Menu.Controls.Add(this.btn3);
            this.panel_Menu.Controls.Add(this.lbl_Terminar);
            this.panel_Menu.Controls.Add(this.btn_Home);
            this.panel_Menu.Controls.Add(this.img_LogOut);
            this.panel_Menu.Controls.Add(this.btn2);
            this.panel_Menu.Controls.Add(this.btn_LogOut);
            this.panel_Menu.Controls.Add(this.btn_Jogos);
            this.panel_Menu.Controls.Add(this.btn1);
            this.panel_Menu.Controls.Add(this.btn_Equipas);
            this.panel_Menu.Controls.Add(this.btn_Estadio);
            this.panel_Menu.Controls.Add(this.btn_Titulos);
            this.panel_Menu.Location = new System.Drawing.Point(0, 63);
            this.panel_Menu.Name = "panel_Menu";
            this.panel_Menu.Size = new System.Drawing.Size(160, 3228);
            this.panel_Menu.TabIndex = 12;
            this.panel_Menu.Visible = false;
            // 
            // lbl_Sessao
            // 
            this.lbl_Sessao.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_Sessao.AutoSize = true;
            this.lbl_Sessao.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Sessao.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_Sessao.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Sessao.Location = new System.Drawing.Point(74, 3174);
            this.lbl_Sessao.Name = "lbl_Sessao";
            this.lbl_Sessao.Size = new System.Drawing.Size(44, 16);
            this.lbl_Sessao.TabIndex = 48;
            this.lbl_Sessao.Text = "Sessão";
            this.lbl_Sessao.Visible = false;
            this.lbl_Sessao.Click += new System.EventHandler(this.Btn_LogOut_Click);
            // 
            // btn3
            // 
            this.btn3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn3.BackColor = System.Drawing.Color.Black;
            this.btn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn3.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3.ForeColor = System.Drawing.Color.White;
            this.btn3.Location = new System.Drawing.Point(12, 324);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(128, 31);
            this.btn3.TabIndex = 48;
            this.btn3.Text = "UTILIZADORES";
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Visible = false;
            this.btn3.Click += new System.EventHandler(this.Btn3_Click);
            // 
            // lbl_Terminar
            // 
            this.lbl_Terminar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_Terminar.AutoSize = true;
            this.lbl_Terminar.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Terminar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_Terminar.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Terminar.Location = new System.Drawing.Point(74, 3158);
            this.lbl_Terminar.Name = "lbl_Terminar";
            this.lbl_Terminar.Size = new System.Drawing.Size(61, 16);
            this.lbl_Terminar.TabIndex = 47;
            this.lbl_Terminar.Text = "Terminar";
            this.lbl_Terminar.Visible = false;
            this.lbl_Terminar.Click += new System.EventHandler(this.Btn_LogOut_Click);
            // 
            // img_LogOut
            // 
            this.img_LogOut.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.img_LogOut.BackColor = System.Drawing.Color.Transparent;
            this.img_LogOut.Cursor = System.Windows.Forms.Cursors.Hand;
            this.img_LogOut.Image = global::FootballLife_WF.Properties.Resources.LogOut;
            this.img_LogOut.Location = new System.Drawing.Point(24, 3149);
            this.img_LogOut.Name = "img_LogOut";
            this.img_LogOut.Size = new System.Drawing.Size(42, 49);
            this.img_LogOut.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.img_LogOut.TabIndex = 46;
            this.img_LogOut.TabStop = false;
            this.img_LogOut.Visible = false;
            this.img_LogOut.Click += new System.EventHandler(this.Btn_LogOut_Click);
            // 
            // btn2
            // 
            this.btn2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn2.BackColor = System.Drawing.Color.Black;
            this.btn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn2.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2.ForeColor = System.Drawing.Color.White;
            this.btn2.Location = new System.Drawing.Point(12, 287);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(128, 31);
            this.btn2.TabIndex = 47;
            this.btn2.Text = "INVENTÁRIO";
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Visible = false;
            this.btn2.Click += new System.EventHandler(this.Btn2_Click);
            // 
            // btn_LogOut
            // 
            this.btn_LogOut.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_LogOut.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_LogOut.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_LogOut.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.btn_LogOut.FlatAppearance.MouseDownBackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_LogOut.FlatAppearance.MouseOverBackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_LogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LogOut.Location = new System.Drawing.Point(12, 3141);
            this.btn_LogOut.Name = "btn_LogOut";
            this.btn_LogOut.Size = new System.Drawing.Size(130, 65);
            this.btn_LogOut.TabIndex = 49;
            this.btn_LogOut.UseVisualStyleBackColor = false;
            this.btn_LogOut.Visible = false;
            this.btn_LogOut.Click += new System.EventHandler(this.Btn_LogOut_Click);
            // 
            // btn1
            // 
            this.btn1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn1.BackColor = System.Drawing.Color.Black;
            this.btn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn1.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.ForeColor = System.Drawing.Color.White;
            this.btn1.Location = new System.Drawing.Point(12, 250);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(128, 31);
            this.btn1.TabIndex = 46;
            this.btn1.Text = "FINANCIAMENTO";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Visible = false;
            this.btn1.Click += new System.EventHandler(this.Btn1_Click);
            // 
            // lbl_Titulo
            // 
            this.lbl_Titulo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbl_Titulo.AutoSize = true;
            this.lbl_Titulo.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Titulo.Font = new System.Drawing.Font("Bauhaus 93", 65.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Titulo.ForeColor = System.Drawing.Color.White;
            this.lbl_Titulo.Location = new System.Drawing.Point(499, 113);
            this.lbl_Titulo.Name = "lbl_Titulo";
            this.lbl_Titulo.Size = new System.Drawing.Size(327, 98);
            this.lbl_Titulo.TabIndex = 15;
            this.lbl_Titulo.Text = "Estádio";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(1, 258);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1363, 127);
            this.panel1.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Berlin Sans FB Demi", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(499, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(332, 24);
            this.label1.TabIndex = 16;
            this.label1.Text = "Temos todo o gosto em recebê-lo!";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(465, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(396, 18);
            this.label3.TabIndex = 18;
            this.label3.Text = "garante-lhe uma ótima visita pelas nossas novas instalações.";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(356, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(619, 18);
            this.label2.TabIndex = 17;
            this.label2.Text = "Seja para assistir aos nossos jogos, torcer pela equipa ou para entrar em campo, " +
    "o Palmelense ";
            // 
            // panel3
            // 
            this.panel3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Location = new System.Drawing.Point(59, 427);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(438, 302);
            this.panel3.TabIndex = 34;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(15, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(405, 271);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // panel9
            // 
            this.panel9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.pictureBox3);
            this.panel9.Location = new System.Drawing.Point(496, 427);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(408, 237);
            this.panel9.TabIndex = 40;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(16, 18);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(369, 205);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 22;
            this.pictureBox3.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.pictureBox4);
            this.panel5.Location = new System.Drawing.Point(899, 709);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(403, 195);
            this.panel5.TabIndex = 41;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(24, 17);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(338, 152);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 25;
            this.pictureBox4.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.pictureBox8);
            this.panel4.Location = new System.Drawing.Point(496, 662);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(404, 181);
            this.panel4.TabIndex = 35;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(9, 16);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(382, 146);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 27;
            this.pictureBox8.TabStop = false;
            // 
            // panel6
            // 
            this.panel6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.pictureBox6);
            this.panel6.Location = new System.Drawing.Point(59, 728);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(438, 347);
            this.panel6.TabIndex = 42;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(27, 29);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(388, 294);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 25;
            this.pictureBox6.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Location = new System.Drawing.Point(496, 842);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(404, 233);
            this.panel2.TabIndex = 40;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(15, 25);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(367, 179);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            // 
            // panel7
            // 
            this.panel7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.pictureBox7);
            this.panel7.Location = new System.Drawing.Point(899, 903);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(403, 172);
            this.panel7.TabIndex = 43;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(26, 17);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(354, 134);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 26;
            this.pictureBox7.TabStop = false;
            // 
            // panel8
            // 
            this.panel8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.pictureBox5);
            this.panel8.Location = new System.Drawing.Point(899, 427);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(403, 283);
            this.panel8.TabIndex = 44;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(24, 18);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(357, 248);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 21;
            this.pictureBox5.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(1245, 1099);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 45;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox9.Image = global::FootballLife_WF.Properties.Resources.Fundo_1;
            this.pictureBox9.Location = new System.Drawing.Point(0, 0);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(1347, 1112);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 46;
            this.pictureBox9.TabStop = false;
            // 
            // Estadio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::FootballLife_WF.Properties.Resources.Fundo_1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1364, 749);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbl_Titulo);
            this.Controls.Add(this.panel_Menu);
            this.Controls.Add(this.img_Logo);
            this.Controls.Add(this.img_Menu);
            this.Controls.Add(this.btn_TopMenu);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.pictureBox9);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MinimumSize = new System.Drawing.Size(1358, 726);
            this.Name = "Estadio";
            this.Text = "FOOTBALL LIFE";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Estadio_Load);
            ((System.ComponentModel.ISupportInitialize)(this.img_Menu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_Logo)).EndInit();
            this.panel_Menu.ResumeLayout(false);
            this.panel_Menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.img_LogOut)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox img_Menu;
        private System.Windows.Forms.PictureBox img_Logo;
        private System.Windows.Forms.Button btn_TopMenu;
        private System.Windows.Forms.Button btn_Titulos;
        private System.Windows.Forms.Button btn_Estadio;
        private System.Windows.Forms.Button btn_Equipas;
        private System.Windows.Forms.Button btn_Jogos;
        private System.Windows.Forms.Button btn_Home;
        private System.Windows.Forms.Panel panel_Menu;
        private System.Windows.Forms.Label lbl_Titulo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Label lbl_Sessao;
        private System.Windows.Forms.Label lbl_Terminar;
        private System.Windows.Forms.PictureBox img_LogOut;
        private System.Windows.Forms.Button btn_LogOut;
        private System.Windows.Forms.PictureBox pictureBox9;
    }
}