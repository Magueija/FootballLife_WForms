﻿namespace FootballLife_WF
{
    partial class FaturaCota
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FaturaCota));
            this.btn_Fechar = new System.Windows.Forms.Button();
            this.btn_Guardar = new System.Windows.Forms.Button();
            this.lbl_NmCartao = new System.Windows.Forms.Label();
            this.label_NmCt = new System.Windows.Forms.Label();
            this.lbl_Numero = new System.Windows.Forms.Label();
            this.label_NrCt = new System.Windows.Forms.Label();
            this.lbl_PayPal = new System.Windows.Forms.Label();
            this.label_PP = new System.Windows.Forms.Label();
            this.lbl_Titulo = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_Nome = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbl_Valor = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl_Mes = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lbl_Pagamento = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lbl_User = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lbl_NIF = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Fechar
            // 
            this.btn_Fechar.BackColor = System.Drawing.Color.White;
            this.btn_Fechar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Fechar.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn_Fechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Fechar.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Fechar.ForeColor = System.Drawing.Color.Black;
            this.btn_Fechar.Location = new System.Drawing.Point(245, 389);
            this.btn_Fechar.Name = "btn_Fechar";
            this.btn_Fechar.Size = new System.Drawing.Size(92, 29);
            this.btn_Fechar.TabIndex = 37;
            this.btn_Fechar.Text = "Fechar";
            this.btn_Fechar.UseVisualStyleBackColor = false;
            this.btn_Fechar.Click += new System.EventHandler(this.Btn_Fechar_Click);
            // 
            // btn_Guardar
            // 
            this.btn_Guardar.BackColor = System.Drawing.Color.White;
            this.btn_Guardar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Guardar.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn_Guardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Guardar.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Guardar.ForeColor = System.Drawing.Color.Black;
            this.btn_Guardar.Location = new System.Drawing.Point(147, 389);
            this.btn_Guardar.Name = "btn_Guardar";
            this.btn_Guardar.Size = new System.Drawing.Size(92, 29);
            this.btn_Guardar.TabIndex = 38;
            this.btn_Guardar.Text = "Guardar";
            this.btn_Guardar.UseVisualStyleBackColor = false;
            this.btn_Guardar.Click += new System.EventHandler(this.Btn_Guardar_Click);
            // 
            // lbl_NmCartao
            // 
            this.lbl_NmCartao.AutoSize = true;
            this.lbl_NmCartao.BackColor = System.Drawing.Color.Transparent;
            this.lbl_NmCartao.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_NmCartao.Location = new System.Drawing.Point(183, 339);
            this.lbl_NmCartao.Name = "lbl_NmCartao";
            this.lbl_NmCartao.Size = new System.Drawing.Size(64, 16);
            this.lbl_NmCartao.TabIndex = 41;
            this.lbl_NmCartao.Text = "nmcartao";
            // 
            // label_NmCt
            // 
            this.label_NmCt.AutoSize = true;
            this.label_NmCt.BackColor = System.Drawing.Color.Transparent;
            this.label_NmCt.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.label_NmCt.Location = new System.Drawing.Point(36, 339);
            this.label_NmCt.Name = "label_NmCt";
            this.label_NmCt.Size = new System.Drawing.Size(136, 16);
            this.label_NmCt.TabIndex = 54;
            this.label_NmCt.Text = ">  NOME DO CARTÃO:";
            // 
            // lbl_Numero
            // 
            this.lbl_Numero.AutoSize = true;
            this.lbl_Numero.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Numero.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Numero.Location = new System.Drawing.Point(195, 318);
            this.lbl_Numero.Name = "lbl_Numero";
            this.lbl_Numero.Size = new System.Drawing.Size(52, 16);
            this.lbl_Numero.TabIndex = 55;
            this.lbl_Numero.Text = "numero";
            // 
            // label_NrCt
            // 
            this.label_NrCt.AutoSize = true;
            this.label_NrCt.BackColor = System.Drawing.Color.Transparent;
            this.label_NrCt.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.label_NrCt.Location = new System.Drawing.Point(36, 318);
            this.label_NrCt.Name = "label_NrCt";
            this.label_NrCt.Size = new System.Drawing.Size(153, 16);
            this.label_NrCt.TabIndex = 56;
            this.label_NrCt.Text = ">  NUMERO DO CARTÃO:";
            // 
            // lbl_PayPal
            // 
            this.lbl_PayPal.AutoSize = true;
            this.lbl_PayPal.BackColor = System.Drawing.Color.Transparent;
            this.lbl_PayPal.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_PayPal.Location = new System.Drawing.Point(112, 318);
            this.lbl_PayPal.Name = "lbl_PayPal";
            this.lbl_PayPal.Size = new System.Drawing.Size(49, 16);
            this.lbl_PayPal.TabIndex = 57;
            this.lbl_PayPal.Text = "paypal";
            this.lbl_PayPal.Visible = false;
            // 
            // label_PP
            // 
            this.label_PP.AutoSize = true;
            this.label_PP.BackColor = System.Drawing.Color.Transparent;
            this.label_PP.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.label_PP.Location = new System.Drawing.Point(36, 318);
            this.label_PP.Name = "label_PP";
            this.label_PP.Size = new System.Drawing.Size(70, 16);
            this.label_PP.TabIndex = 58;
            this.label_PP.Text = ">  PALPAL:";
            this.label_PP.Visible = false;
            // 
            // lbl_Titulo
            // 
            this.lbl_Titulo.AutoSize = true;
            this.lbl_Titulo.Font = new System.Drawing.Font("Bauhaus 93", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Titulo.Location = new System.Drawing.Point(88, 26);
            this.lbl_Titulo.Name = "lbl_Titulo";
            this.lbl_Titulo.Size = new System.Drawing.Size(171, 21);
            this.lbl_Titulo.TabIndex = 95;
            this.lbl_Titulo.Text = "FATURA DA COTA";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(25, 88);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 16);
            this.label7.TabIndex = 94;
            this.label7.Text = "NOME:";
            // 
            // lbl_Nome
            // 
            this.lbl_Nome.AutoSize = true;
            this.lbl_Nome.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Nome.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Nome.Location = new System.Drawing.Point(80, 88);
            this.lbl_Nome.Name = "lbl_Nome";
            this.lbl_Nome.Size = new System.Drawing.Size(40, 16);
            this.lbl_Nome.TabIndex = 93;
            this.lbl_Nome.Text = "nome";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(25, 120);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 16);
            this.label6.TabIndex = 92;
            this.label6.Text = "VALOR:";
            // 
            // lbl_Valor
            // 
            this.lbl_Valor.AutoSize = true;
            this.lbl_Valor.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Valor.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Valor.Location = new System.Drawing.Point(84, 120);
            this.lbl_Valor.Name = "lbl_Valor";
            this.lbl_Valor.Size = new System.Drawing.Size(37, 16);
            this.lbl_Valor.TabIndex = 91;
            this.lbl_Valor.Text = "valor";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.label10.Location = new System.Drawing.Point(25, 151);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 16);
            this.label10.TabIndex = 90;
            this.label10.Text = "MÊS:";
            // 
            // lbl_Mes
            // 
            this.lbl_Mes.AutoSize = true;
            this.lbl_Mes.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Mes.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Mes.Location = new System.Drawing.Point(66, 151);
            this.lbl_Mes.Name = "lbl_Mes";
            this.lbl_Mes.Size = new System.Drawing.Size(30, 16);
            this.lbl_Mes.TabIndex = 89;
            this.lbl_Mes.Text = "mes";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.label11.Location = new System.Drawing.Point(25, 208);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(167, 16);
            this.label11.TabIndex = 88;
            this.label11.Text = "MÉTODO DE PAGAMENTO:";
            // 
            // lbl_Pagamento
            // 
            this.lbl_Pagamento.AutoSize = true;
            this.lbl_Pagamento.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Pagamento.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Pagamento.Location = new System.Drawing.Point(198, 208);
            this.lbl_Pagamento.Name = "lbl_Pagamento";
            this.lbl_Pagamento.Size = new System.Drawing.Size(76, 16);
            this.lbl_Pagamento.TabIndex = 87;
            this.lbl_Pagamento.Text = "pagamento";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.label12.Location = new System.Drawing.Point(36, 247);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(92, 16);
            this.label12.TabIndex = 86;
            this.label12.Text = ">  UTLIZADOR:";
            // 
            // lbl_User
            // 
            this.lbl_User.AutoSize = true;
            this.lbl_User.BackColor = System.Drawing.Color.Transparent;
            this.lbl_User.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_User.Location = new System.Drawing.Point(134, 247);
            this.lbl_User.Name = "lbl_User";
            this.lbl_User.Size = new System.Drawing.Size(31, 16);
            this.lbl_User.TabIndex = 85;
            this.lbl_User.Text = "user";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.label13.Location = new System.Drawing.Point(36, 274);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 16);
            this.label13.TabIndex = 84;
            this.label13.Text = ">  NIF:";
            // 
            // lbl_NIF
            // 
            this.lbl_NIF.AutoSize = true;
            this.lbl_NIF.BackColor = System.Drawing.Color.Transparent;
            this.lbl_NIF.Font = new System.Drawing.Font("Berlin Sans FB Demi", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_NIF.Location = new System.Drawing.Point(85, 274);
            this.lbl_NIF.Name = "lbl_NIF";
            this.lbl_NIF.Size = new System.Drawing.Size(23, 16);
            this.lbl_NIF.TabIndex = 83;
            this.lbl_NIF.Text = "nif";
            // 
            // FaturaCota
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(349, 430);
            this.Controls.Add(this.lbl_Titulo);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbl_Nome);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbl_Valor);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lbl_Mes);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.lbl_Pagamento);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lbl_User);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lbl_NIF);
            this.Controls.Add(this.label_PP);
            this.Controls.Add(this.lbl_PayPal);
            this.Controls.Add(this.label_NrCt);
            this.Controls.Add(this.lbl_Numero);
            this.Controls.Add(this.label_NmCt);
            this.Controls.Add(this.lbl_NmCartao);
            this.Controls.Add(this.btn_Guardar);
            this.Controls.Add(this.btn_Fechar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FaturaCota";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Fatura da Cota";
            this.Load += new System.EventHandler(this.FaturaCota_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Fechar;
        private System.Windows.Forms.Button btn_Guardar;
        private System.Windows.Forms.Label lbl_NmCartao;
        private System.Windows.Forms.Label label_NmCt;
        private System.Windows.Forms.Label lbl_Numero;
        private System.Windows.Forms.Label label_NrCt;
        private System.Windows.Forms.Label lbl_PayPal;
        private System.Windows.Forms.Label label_PP;
        private System.Windows.Forms.Label lbl_Titulo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_Nome;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbl_Valor;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbl_Mes;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lbl_Pagamento;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbl_User;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbl_NIF;
    }
}